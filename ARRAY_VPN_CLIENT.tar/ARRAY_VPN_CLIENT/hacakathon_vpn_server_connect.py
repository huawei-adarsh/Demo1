#!/usr/bin/python

import os,time
import socket
import fcntl
import struct

def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

ts = time.time()
os.system("sudo chown -v root array_vpnc")
os.system("sudo chown -v root vpn_cmdline") 
os.system("sudo chmod 4755 vpn_cmdline") 
os.system("sudo chmod 4755 array_vpnc")
os.system("./vpn_cmdline -s")
os.system("./vpn_cmdline -s")
time.sleep(5)
os.system("sudo ./vpn_cmdline -h 194.213.3.244 -o 5555 -u esdk01 -p Huawei.12#$  &")
time.sleep(15)
ip = get_ip_address('tun0')
if os.system("ping -c 4 172.19.37.161") == 0:
    print "*********************************************"
    print "HUAEWI ROUTER 172.19.37.161 is reachable"
    print "*********************************************"
    
print "**********************************"
print "VPN TUNNEL IP is : " + ip
print "please use this Ip for json request"
print "**********************************"
